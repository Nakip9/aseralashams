"use client";

import {
  Award,
  Users,
  Handshake,
  Headphones,
  type LucideIcon,
} from "lucide-react";
import { WHY_US } from "./data";
import { Reveal, StaggerContainer, StaggerItem } from "./Reveal";

const ICONS: Record<string, LucideIcon> = {
  Award,
  Users,
  Handshake,
  Headphones,
};

export function WhyUs() {
  return (
    <section className="relative py-24 sm:py-32 overflow-hidden">
      {/* Top divider with sun glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-px bg-gradient-to-r from-transparent via-brand-green/40 to-transparent" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-72 h-72 rounded-full bg-brand-green/10 blur-[100px] pointer-events-none" />

      <div className="container mx-auto px-4 relative">
        <Reveal className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-xs sm:text-sm text-brand-green-dark tracking-widest font-mono uppercase mb-3">
            لماذا نحن
          </span>
          <h2 className="font-heading font-extrabold text-3xl sm:text-5xl mb-5">
            <span className="text-foreground">لماذا تختار </span>
            <span className="text-gradient-solar">عصر الشمس؟</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            نمتلك الخبرة والشراكات والفريق المتخصص لضمان حصولك على أفضل حل طاقة شمسية، مع متابعة كاملة بعد التركيب وخدمة دعم متواصلة.
          </p>
        </Reveal>

        <StaggerContainer
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6"
          stagger={0.1}
        >
          {WHY_US.map((item, i) => {
            const Icon = ICONS[item.icon] ?? Award;
            return (
              <StaggerItem key={i}>
                <div className="group bento-card p-7 h-full text-center">
                  <div className="relative inline-flex mb-5">
                    <div className="absolute inset-0 rounded-2xl bg-brand-green/30 blur-xl group-hover:bg-brand-green/50 transition-colors" />
                    <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-brand-green to-brand-blue flex items-center justify-center group-hover:rotate-6 transition-transform duration-500">
                      <Icon className="w-8 h-8 text-white" strokeWidth={2.2} />
                    </div>
                  </div>
                  <h3 className="font-heading font-bold text-lg sm:text-xl mb-3 group-hover:text-brand-green-dark transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </StaggerItem>
            );
          })}
        </StaggerContainer>
      </div>
    </section>
  );
}
