"use client";

import {
  Sun,
  Wrench,
  Lightbulb,
  Zap,
  Factory,
  Home,
  ArrowLeft,
  type LucideIcon,
} from "lucide-react";
import { SERVICES } from "./data";
import { Reveal, StaggerContainer, StaggerItem } from "./Reveal";

const ICONS: Record<string, LucideIcon> = {
  Sun,
  Wrench,
  Lightbulb,
  Zap,
  Factory,
  Home,
};

export function Services() {
  return (
    <section id="services" className="relative py-24 sm:py-32 overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 bg-grid opacity-20 pointer-events-none" />
      <div className="absolute top-0 left-1/4 w-[30rem] h-[30rem] rounded-full bg-brand-green/5 blur-[120px] pointer-events-none" />

      <div className="container mx-auto px-4 relative">
        <Reveal className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-xs sm:text-sm text-brand-green-dark tracking-widest font-mono uppercase mb-3">
            خدماتنا
          </span>
          <h2 className="font-heading font-extrabold text-3xl sm:text-5xl mb-5">
            <span className="text-foreground">حلول طاقة </span>
            <span className="text-gradient-solar">متكاملة واحترافية</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            من التركيب إلى الصيانة، ومن الاستشارات إلى حلول المصانع والمنازل — نقدم خدمات شاملة تغطي كافة احتياجاتك في عالم الطاقة الشمسية.
          </p>
        </Reveal>

        <StaggerContainer
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6"
          stagger={0.08}
        >
          {SERVICES.map((s, i) => {
            const Icon = ICONS[s.icon] ?? Sun;
            return (
              <StaggerItem key={i}>
                <ServiceCard
                  Icon={Icon}
                  title={s.title}
                  description={s.description}
                  index={i + 1}
                />
              </StaggerItem>
            );
          })}
        </StaggerContainer>

        <Reveal delay={0.1} className="text-center mt-14">
          <a
            href="#contact"
            className="inline-flex items-center gap-2 rounded-full glass-strong px-7 py-3.5 text-sm sm:text-base font-semibold text-foreground hover:bg-brand-green/10 transition-all group"
          >
            <span>استعرض جميع الخدمات</span>
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          </a>
        </Reveal>
      </div>
    </section>
  );
}

function ServiceCard({
  Icon,
  title,
  description,
  index,
}: {
  Icon: LucideIcon;
  title: string;
  description: string;
  index: number;
}) {
  return (
    <article className="group relative bento-card p-7 h-full overflow-hidden">
      {/* Number watermark */}
      <span className="absolute -top-4 -left-2 font-heading font-extrabold text-8xl text-brand-green/5 select-none pointer-events-none">
        {String(index).padStart(2, "0")}
      </span>

      {/* Hover glow */}
      <div className="absolute inset-0 bg-gradient-to-br from-brand-green/0 to-brand-blue/0 group-hover:from-brand-green/5 group-hover:to-brand-blue/10 transition-all duration-500 pointer-events-none" />

      <div className="relative">
        <div className="w-14 h-14 rounded-2xl glass-strong flex items-center justify-center mb-5 group-hover:bg-gradient-to-br group-hover:from-brand-green group-hover:to-brand-blue transition-all duration-500">
          <Icon
            className="w-7 h-7 text-brand-green-dark group-hover:text-white transition-colors duration-500"
            strokeWidth={2.2}
          />
        </div>

        <h3 className="font-heading font-bold text-xl mb-3 group-hover:text-brand-green-dark transition-colors">
          {title}
        </h3>
        <p className="text-slate-600 text-sm leading-relaxed">{description}</p>
      </div>

      {/* Bottom border accent */}
      <div className="absolute bottom-0 inset-x-0 h-px bg-gradient-to-l from-transparent via-brand-green/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
    </article>
  );
}
