"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Phone, MessageSquare } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { COMPANY, NAV_LINKS } from "./data";
import { cn } from "@/lib/utils";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [hash, setHash] = useState("#home");
  const pathname = usePathname();
  const isHome = pathname === "/";

  useEffect(() => {
    if (!isHome) return;
    const updateHash = () => setHash(window.location.hash || "#home");
    updateHash();
    window.addEventListener("hashchange", updateHash);
    return () => window.removeEventListener("hashchange", updateHash);
  }, [isHome]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!isHome) return;
    const sections = NAV_LINKS.filter((l) => l.href.startsWith("#")).map((l) =>
      document.querySelector(l.href)
    );
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            window.history.replaceState(null, "", `#${e.target.id}`);
            setHash(`#${e.target.id}`);
          }
        });
      },
      { rootMargin: "-40% 0px -55% 0px" }
    );
    sections.forEach((s) => s && obs.observe(s));
    return () => obs.disconnect();
  }, [isHome]);

  const solidNav = scrolled || !isHome;
  const active = isHome ? hash : pathname;

  const scrollToContact = () => {
    if (isHome) {
      const form = document.getElementById("contact-form");
      if (form) {
        form.scrollIntoView({ behavior: "smooth", block: "center" });
        setTimeout(() => {
          const nameInput = form.querySelector("input[name='name']") as HTMLInputElement | null;
          nameInput?.focus({ preventScroll: true });
        }, 700);
      }
    }
    setOpen(false);
  };

  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className={cn(
        "fixed top-0 inset-x-0 z-50 transition-all duration-500",
        solidNav ? "py-2" : "py-3 sm:py-4"
      )}
    >
      <div className="container mx-auto px-4">
        <nav
          className={cn(
            "flex items-center justify-between rounded-2xl px-3 sm:px-5 py-2.5 sm:py-3 transition-all duration-500",
            solidNav ? "glass-strong shadow-xl shadow-brand-green/5" : "bg-transparent"
          )}
        >
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 sm:gap-3 group flex-shrink-0">
            <div className="relative">
              <div className="absolute inset-0 rounded-full bg-brand-green/30 blur-md group-hover:bg-brand-green/50 transition-all" />
              <div className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-white shadow-lg ring-1 ring-brand-green/20 overflow-hidden flex items-center justify-center group-hover:ring-brand-green/40 group-hover:scale-105 transition-all">
                <img
                  src="/brand/logo.png"
                  alt="شعار عصر الشمس"
                  className="w-full h-full object-cover"
                  width={44}
                  height={44}
                />
              </div>
            </div>
            <div className="flex flex-col leading-tight">
              <span
                className={cn(
                  "font-heading font-bold text-base sm:text-lg transition-colors",
                  solidNav ? "text-foreground" : "text-white"
                )}
              >
                {COMPANY.name}
              </span>
              <span
                className={cn(
                  "text-[10px] tracking-wider font-mono uppercase transition-colors",
                  solidNav ? "text-brand-green-dark/80" : "text-brand-green-lighter"
                )}
              >
                {COMPANY.latinName}
              </span>
            </div>
          </Link>

          {/* Desktop links */}
          <ul className="hidden lg:flex items-center gap-0.5">
            {NAV_LINKS.map((link) => {
              const linkHref = isHome ? link.href : link.route;
              const isActive = isHome ? active === link.href : pathname === link.route;
              return (
                <li key={link.route}>
                  <Link
                    href={linkHref}
                    className={cn(
                      "relative px-3.5 py-2 text-sm font-medium rounded-lg transition-colors",
                      isActive
                        ? solidNav
                          ? "text-brand-green-dark"
                          : "text-brand-green-lighter"
                        : solidNav
                          ? "text-slate-600 hover:text-brand-green-dark"
                          : "text-white/85 hover:text-white"
                    )}
                  >
                    {link.label}
                    {isActive && (
                      <motion.span
                        layoutId="nav-active"
                        className={cn(
                          "absolute inset-0 rounded-lg border transition-colors",
                          solidNav
                            ? "bg-brand-green/10 border-brand-green/30"
                            : "bg-white/10 border-white/30"
                        )}
                        transition={{ type: "spring", stiffness: 380, damping: 30 }}
                      />
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>

          {/* CTA + mobile toggle */}
          <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
            <Link
              href={isHome ? "#contact" : "/contact"}
              onClick={isHome ? scrollToContact : undefined}
              className="hidden sm:inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand-green to-brand-blue px-4 sm:px-5 py-2 text-sm font-semibold text-white shadow-lg shadow-brand-green/25 hover:shadow-brand-green/40 hover:scale-105 transition-all"
            >
              <MessageSquare className="w-4 h-4" />
              <span className="hidden md:inline">تحدّث مع خبير</span>
              <span className="md:hidden ltr-nums">{COMPANY.phones[0]}</span>
            </Link>

            <button
              type="button"
              aria-label="القائمة"
              onClick={() => setOpen((v) => !v)}
              className={cn(
                "lg:hidden inline-flex items-center justify-center w-10 h-10 rounded-xl transition-colors",
                solidNav
                  ? "glass text-foreground hover:bg-brand-green/10"
                  : "bg-white/10 backdrop-blur-md border border-white/30 text-white hover:bg-white/20"
              )}
            >
              {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </nav>

        {/* Mobile drawer */}
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, y: -10, height: 0 }}
              animate={{ opacity: 1, y: 0, height: "auto" }}
              exit={{ opacity: 0, y: -10, height: 0 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
              className="lg:hidden mt-2 overflow-hidden"
            >
              <ul className="glass-strong rounded-2xl p-3 flex flex-col gap-1">
                {NAV_LINKS.map((link) => {
                  const linkHref = isHome ? link.href : link.route;
                  const isActive = isHome ? active === link.href : pathname === link.route;
                  return (
                    <li key={link.route}>
                      <Link
                        href={linkHref}
                        onClick={() => setOpen(false)}
                        className={cn(
                          "block px-4 py-3 rounded-xl text-sm font-medium transition-colors",
                          isActive
                            ? "bg-brand-green/10 text-brand-green-dark border border-brand-green/30"
                            : "text-slate-600 hover:bg-brand-green/5"
                        )}
                      >
                        {link.label}
                      </Link>
                    </li>
                  );
                })}
                <li>
                  <Link
                    href={isHome ? "#contact" : "/contact"}
                    onClick={() => { if (isHome) scrollToContact(); else setOpen(false); }}
                    className="mt-1 w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-brand-green to-brand-blue px-4 py-3 text-sm font-semibold text-white"
                  >
                    <MessageSquare className="w-4 h-4" />
                    تحدّث مع خبير
                  </Link>
                </li>
              </ul>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.header>
  );
}
