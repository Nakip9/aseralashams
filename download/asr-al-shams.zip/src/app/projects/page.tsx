"use client";

import Link from "next/link";
import { MapPin, Zap, ArrowLeft, Calendar, Briefcase, TrendingUp } from "lucide-react";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { Reveal, StaggerContainer, StaggerItem } from "@/components/site/Reveal";
import { CountUp } from "@/components/site/CountUp";
import { useStore } from "@/lib/store";
import type { Project } from "@/lib/types";

export default function ProjectsPage() {
  const projects = useStore((s) => s.projects);
  const totalCapacity = projects.reduce((sum, p) => sum + (parseFloat(p.capacity) || 0), 0);
  const maxCapacity = Math.max(...projects.map((p) => parseFloat(p.capacity) || 0), 0);

  return (
    <PageLayout>
      <PageHero
        image="/hero/hero-bg-2.jpg"
        eyebrow="مشاريعنا"
        title="مشاريعنا"
        subtitle="من محطات تجارية كبرى إلى مراكز تسوق وأنظمة ضخ مياه مجتمعية — مشاريع متنوعة تجسد خبرتنا في تصميم وتركيب أنظمة الطاقة الشمسية المتكاملة."
        breadcrumb="مشاريعنا"
      />

      <section className="py-16 sm:py-24 relative overflow-hidden">
        <div className="absolute top-1/4 -right-32 w-[28rem] h-[28rem] rounded-full bg-brand-blue/8 blur-[120px] pointer-events-none" />
        <div className="absolute bottom-1/4 -left-32 w-[28rem] h-[28rem] rounded-full bg-brand-green/8 blur-[120px] pointer-events-none" />

        <div className="container mx-auto px-4 relative">
          <Reveal className="mb-12">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard icon={Briefcase} value={projects.length} label="إجمالي المشاريع" color="from-brand-green to-emerald-500" />
              <StatCard icon={Zap} value={totalCapacity} suffix=" kW" label="إجمالي السعة" color="from-brand-blue to-indigo-500" />
              <StatCard icon={TrendingUp} value={maxCapacity} suffix=" kW" label="أكبر مشروع" color="from-emerald-500 to-teal-600" />
              <StatCard icon={Calendar} value={4} suffix="+" label="سنوات الخبرة" color="from-brand-green to-brand-blue" />
            </div>
          </Reveal>

          {projects.length === 0 ? (
            <div className="text-center py-20 text-slate-400"><Briefcase className="w-16 h-16 mx-auto mb-4 opacity-30" /><p>لا توجد مشاريع</p></div>
          ) : (
            <StaggerContainer className="space-y-8 sm:space-y-12" stagger={0.15}>
              {projects.map((project, i) => <ProjectRow key={project.id} project={project} index={i} />)}
            </StaggerContainer>
          )}

          <Reveal className="mt-16">
            <div className="relative glass-strong rounded-3xl p-8 sm:p-12 overflow-hidden text-center">
              <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-brand-green/20 blur-3xl animate-pulse-glow" />
              <div className="absolute -bottom-20 -left-20 w-72 h-72 rounded-full bg-brand-blue/20 blur-3xl animate-pulse-glow" />
              <div className="relative">
                <h2 className="font-heading font-extrabold text-2xl sm:text-3xl mb-3">ابدأ مشروعك القادم معنا</h2>
                <p className="text-slate-600 max-w-xl mx-auto mb-6">انضم إلى عملائنا الناجحين وابدأ رحلتك نحو الطاقة المستدامة.</p>
                <Link href="/contact" className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand-green to-brand-blue px-7 py-3.5 text-sm font-bold text-white shadow-lg hover:scale-105 transition-all">اطلب عرض سعر الآن<ArrowLeft className="w-4 h-4" /></Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </PageLayout>
  );
}

function StatCard({ icon: Icon, value, suffix, label, color }: { icon: typeof Briefcase; value: number; suffix?: string; label: string; color: string }) {
  return (
    <div className="bento-card p-5 text-center group">
      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-3 mx-auto group-hover:scale-110 transition-transform`}><Icon className="w-6 h-6 text-white" /></div>
      <div className="text-2xl sm:text-3xl font-heading font-extrabold text-gradient-solar"><CountUp end={value} suffix={suffix} duration={2} /></div>
      <div className="text-xs sm:text-sm text-slate-500 mt-1">{label}</div>
    </div>
  );
}

function ProjectRow({ project, index }: { project: Project; index: number }) {
  const isReversed = index % 2 === 1;
  return (
    <article className={`grid lg:grid-cols-2 gap-6 lg:gap-10 items-center ${isReversed ? "lg:[direction:rtl]" : ""}`}>
      <div className={`relative aspect-[4/3] rounded-3xl overflow-hidden shadow-xl group ${isReversed ? "lg:[direction:ltr]" : ""}`}>
        {project.image ? (
          <img src={project.image} alt={project.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
        ) : (
          <>
            <div className={`absolute inset-0 bg-gradient-to-br ${project.accent}`} />
            <div className="absolute inset-0 bg-grid opacity-30" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="grid grid-cols-4 gap-2 opacity-40">
                {Array.from({ length: 16 }).map((_, i) => <div key={i} className="w-12 h-16 rounded-sm bg-slate-900/60 border border-white/20" />)}
              </div>
            </div>
          </>
        )}
        <div className="absolute top-4 right-4 glass-strong rounded-full px-4 py-2 flex items-center gap-2">
          <Zap className="w-4 h-4 text-brand-green-dark" />
          <span className="text-sm font-bold text-brand-green-dark ltr-nums">{project.capacity}</span>
          <span className="text-xs text-slate-700">{project.unit}</span>
        </div>
        <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-slate-950/80 to-transparent" />
      </div>
      <div className={isReversed ? "lg:[direction:rtl]" : ""}>
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <span className="inline-flex items-center gap-1 rounded-full bg-brand-green/10 border border-brand-green/30 px-3 py-1 text-xs text-brand-green-dark font-mono">{project.type}</span>
          <span className="inline-flex items-center gap-1 text-xs text-slate-500"><MapPin className="w-3.5 h-3.5" />{project.location}</span>
          {project.date && <span className="inline-flex items-center gap-1 text-xs text-slate-500 ltr-nums"><Calendar className="w-3.5 h-3.5" />{project.date}</span>}
        </div>
        <h3 className="font-heading font-extrabold text-2xl sm:text-3xl mb-4">{project.title}</h3>
        <p className="text-slate-600 leading-relaxed mb-6 text-sm sm:text-base">{project.description}</p>
        <div className="flex items-end gap-4 mb-6">
          <div>
            <div className="text-xs text-slate-400 uppercase font-mono tracking-wider mb-1">السعة المركّبة</div>
            <div className="font-heading font-extrabold text-4xl text-gradient-solar ltr-nums leading-none">{project.capacity}</div>
            <div className="text-sm text-brand-green-dark mt-1">{project.unit}</div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <Link href="/contact" className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand-green to-brand-blue px-5 py-2.5 text-sm font-semibold text-white shadow-md hover:scale-105 transition-all">عرض التفاصيل<ArrowLeft className="w-4 h-4" /></Link>
          <Link href="/contact" className="inline-flex items-center gap-2 rounded-full glass-strong px-5 py-2.5 text-sm font-semibold text-foreground hover:bg-brand-green/10 transition-all">اطلب مشروعاً مماثلاً</Link>
        </div>
      </div>
    </article>
  );
}
