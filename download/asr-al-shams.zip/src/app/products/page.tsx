"use client";

import Link from "next/link";
import {
  Sun, Zap, BatteryCharging, Cable, Lightbulb, Wrench, Factory, Home,
  ArrowLeft, ArrowUpRight, Package,
  type LucideIcon,
} from "lucide-react";
import { motion } from "framer-motion";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { Reveal, StaggerContainer, StaggerItem } from "@/components/site/Reveal";
import { useStore } from "@/lib/store";

const ICONS: Record<string, LucideIcon> = {
  Sun, Zap, BatteryCharging, Cable, Lightbulb, Wrench, Factory, Home,
};

const CATEGORY_ACCENTS: Record<string, string> = {
  panels: "from-emerald-500 to-brand-blue",
  inverters: "from-brand-blue to-indigo-600",
  batteries: "from-emerald-400 to-teal-600",
  cables: "from-cyan-500 to-brand-blue",
};

export default function ProductsPage() {
  const products = useStore((s) => s.products);
  const categories = useStore((s) => s.categories);

  return (
    <PageLayout>
      <PageHero
        image="/hero/hero-bg-1.jpg"
        eyebrow="منتجات الطاقة الشمسية"
        title="منتجاتنا"
        subtitle="نوفر مجموعة متكاملة من منتجات الطاقة الشمسية عالية الجودة، مختارة بعناية من أفضل العلامات التجارية العالمية. اختر القسم لاستعرض منتجاته."
        breadcrumb="منتجاتنا"
      />

      <section className="py-16 sm:py-24 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[30rem] h-[30rem] rounded-full bg-brand-green/5 blur-[120px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[30rem] h-[30rem] rounded-full bg-brand-blue/5 blur-[120px] pointer-events-none" />

        <div className="container mx-auto px-4 relative">
          <Reveal className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-heading font-extrabold text-2xl sm:text-3xl mb-3">اختر القسم</h2>
            <p className="text-slate-600 text-sm sm:text-base">
              لدينا {categories.length} أقسام رئيسية للمنتجات. اضغط على أي قسم لاستعرض جميع منتجاته التفصيلية.
            </p>
          </Reveal>

          <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 gap-5 sm:gap-6" stagger={0.1}>
            {categories.map((cat) => {
              const Icon = ICONS[cat.icon] ?? Sun;
              const count = products.filter((p) => p.categoryId === cat.id).length;
              const accent = CATEGORY_ACCENTS[cat.id] || "from-brand-green to-brand-blue";
              return (
                <StaggerItem key={cat.id}>
                  <Link
                    href={`/products/category/${cat.id}`}
                    className="group relative block bento-card p-8 h-full overflow-hidden"
                  >
                    {/* Accent halo */}
                    <div className={`absolute -top-20 -left-20 w-64 h-64 rounded-full bg-gradient-to-br ${accent} opacity-15 group-hover:opacity-30 blur-3xl transition-opacity duration-700`} />

                    <div className="relative flex items-start gap-5">
                      {/* Icon */}
                      <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${accent} flex items-center justify-center shadow-lg flex-shrink-0 group-hover:scale-110 group-hover:rotate-6 transition-transform duration-500`}>
                        <Icon className="w-10 h-10 text-white" strokeWidth={2.2} />
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 mb-2">
                          <h3 className="font-heading font-bold text-xl sm:text-2xl group-hover:text-brand-green-dark transition-colors">
                            {cat.name}
                          </h3>
                          <ArrowUpRight className="w-5 h-5 text-slate-400 group-hover:text-brand-green-dark group-hover:translate-x-1 group-hover:-translate-y-1 transition-all flex-shrink-0" />
                        </div>

                        <p className="text-slate-600 text-sm leading-relaxed mb-4 line-clamp-2">
                          {cat.description}
                        </p>

                        <div className="flex items-center gap-3">
                          <span className="inline-flex items-center gap-1.5 rounded-full bg-brand-green/10 border border-brand-green/30 px-3 py-1 text-xs text-brand-green-dark font-mono">
                            <Package className="w-3 h-3" />
                            <span className="ltr-nums font-bold">{count}</span>
                            {count === 1 ? "منتج" : "منتجات"}
                          </span>
                          <span className="text-xs text-slate-400 group-hover:text-brand-green-dark transition-colors">
                            اضغط للاستعراض ←
                          </span>
                        </div>
                      </div>
                    </div>
                  </Link>
                </StaggerItem>
              );
            })}
          </StaggerContainer>

          {/* CTA */}
          <Reveal className="mt-16">
            <div className="relative glass-strong rounded-3xl p-8 sm:p-12 overflow-hidden text-center">
              <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-brand-green/20 blur-3xl animate-pulse-glow" />
              <div className="absolute -bottom-20 -left-20 w-72 h-72 rounded-full bg-brand-blue/20 blur-3xl animate-pulse-glow" />
              <div className="relative">
                <h2 className="font-heading font-extrabold text-2xl sm:text-3xl mb-3">هل تحتاج استشارة؟</h2>
                <p className="text-slate-600 max-w-xl mx-auto mb-6">فريقنا جاهز لمساعدتك في اختيار المنتج الأمثل لمشروعك.</p>
                <Link href="/contact" className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand-green to-brand-blue px-7 py-3.5 text-sm font-bold text-white shadow-lg hover:scale-105 transition-all">
                  اطلب عرض سعر الآن
                  <ArrowLeft className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </PageLayout>
  );
}
