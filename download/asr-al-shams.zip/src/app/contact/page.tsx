"use client";

import { useState } from "react";
import { MapPin, Phone, Mail, Send, Clock, Facebook, Linkedin, MessageCircle, Sparkles, CheckCircle2 } from "lucide-react";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { Reveal, StaggerContainer, StaggerItem } from "@/components/site/Reveal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { COMPANY } from "@/components/site/data";

export default function ContactPage() {
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 900));
    setSubmitting(false);
    setSubmitted(true);
    toast.success("تم إرسال طلبك بنجاح!", { description: "سيتواصل معك فريقنا خلال 24 ساعة عمل." });
    (e.target as HTMLFormElement).reset();
    setTimeout(() => setSubmitted(false), 4000);
  }

  const infoCards = [
    { icon: MapPin, label: "العنوان", value: COMPANY.address },
    { icon: Phone, label: "أرقام الهاتف", value: COMPANY.phones.join(" · "), isLink: true, href: `tel:${COMPANY.phones[0]}` },
    { icon: Mail, label: "البريد الإلكتروني", value: COMPANY.emails.join(" · "), isLink: true, href: `mailto:${COMPANY.emails[0]}` },
    { icon: Clock, label: "ساعات العمل", value: "السبت – الخميس: 8:00 ص – 5:00 م" },
  ];

  return (
    <PageLayout>
      <PageHero
        image="/hero/hero-bg-2.jpg"
        eyebrow="تواصل معنا"
        title="تواصل معنا"
        subtitle="تواصل معنا عبر القنوات التالية، أو املأ النموذج وسيتواصل معك فريقنا في أقرب وقت ممكن."
        breadcrumb="تواصل معنا"
      />

      <section className="py-16 sm:py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-aurora opacity-60" />
        <div className="absolute top-1/3 -right-32 w-[28rem] h-[28rem] rounded-full bg-brand-green/8 blur-[120px] pointer-events-none" />

        <div className="container mx-auto px-4 relative">
          {/* Info cards */}
          <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12" stagger={0.08}>
            {infoCards.map((card, i) => {
              const Icon = card.icon;
              return (
                <StaggerItem key={i}>
                  <div className="bento-card p-6 h-full">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-brand-green to-brand-blue flex items-center justify-center mb-4 shadow-md">
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-[11px] text-slate-500 mb-1 tracking-wide uppercase font-mono">{card.label}</div>
                    {card.isLink ? (
                      <a href={card.href} className="text-sm text-slate-700 hover:text-brand-green-dark transition-colors leading-relaxed ltr-nums" dir="ltr">{card.value}</a>
                    ) : (
                      <div className="text-sm text-slate-700 leading-relaxed">{card.value}</div>
                    )}
                  </div>
                </StaggerItem>
              );
            })}
          </StaggerContainer>

          <div className="grid lg:grid-cols-2 gap-6 lg:gap-10">
            {/* Form */}
            <Reveal>
              <form onSubmit={onSubmit} className="glass-strong rounded-3xl p-6 sm:p-8 space-y-5 relative overflow-hidden">
                {submitted && (
                  <div className="absolute inset-0 bg-white/95 backdrop-blur-sm flex items-center justify-center z-10 rounded-3xl">
                    <div className="text-center">
                      <div className="w-16 h-16 rounded-full bg-gradient-to-br from-brand-green to-brand-blue flex items-center justify-center mx-auto mb-4 animate-pulse-glow">
                        <CheckCircle2 className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="font-heading font-bold text-xl text-slate-900 mb-2">تم إرسال طلبك بنجاح!</h3>
                      <p className="text-slate-600 text-sm">سيتواصل معك فريقنا خلال 24 ساعة عمل.</p>
                    </div>
                  </div>
                )}
                <div>
                  <h3 className="font-heading font-bold text-xl text-slate-900 mb-1">تفاصيل المشروع</h3>
                  <p className="text-sm text-slate-500">بالضغط على إرسال، أنت توافق على أن يتواصل معك فريق عصر الشمس بشأن طلبك.</p>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700 block">الاسم الكامل</label>
                    <Input id="name" name="name" required placeholder="مثال: أحمد محمد" className="bg-white/70 border-brand-green/20 focus:border-brand-green/50 focus-visible:ring-brand-green/30" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700 block">رقم الهاتف</label>
                    <Input id="phone" name="phone" required type="tel" placeholder="7XX XXX XXX" className="bg-white/70 border-brand-green/20 focus:border-brand-green/50 focus-visible:ring-brand-green/30 ltr-nums" dir="ltr" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700 block">البريد الإلكتروني</label>
                  <Input id="email" name="email" type="email" placeholder="you@example.com" className="bg-white/70 border-brand-green/20 focus:border-brand-green/50 focus-visible:ring-brand-green/30 ltr-nums" dir="ltr" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700 block">نوع المشروع</label>
                  <select id="projectType" name="projectType" className="w-full h-10 rounded-md bg-white/70 border border-brand-green/20 px-3 text-sm focus:border-brand-green/50 focus:outline-none focus:ring-2 focus:ring-brand-green/30">
                    <option value="residential">سكني</option>
                    <option value="commercial">تجاري</option>
                    <option value="industrial">صناعي</option>
                    <option value="agricultural">زراعي / ضخ مياه</option>
                    <option value="other">أخرى</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700 block">تفاصيل المشروع</label>
                  <Textarea id="message" name="message" required rows={5} placeholder="اكتب تفاصيل مشروعك: السعة المطلوبة، الموقع، نوع الاستخدام..." className="bg-white/70 border-brand-green/20 focus:border-brand-green/50 focus-visible:ring-brand-green/30 resize-none" />
                </div>
                <Button type="submit" disabled={submitting} className="w-full h-12 rounded-xl bg-gradient-to-r from-brand-green to-brand-blue hover:opacity-90 text-white font-bold text-base shadow-lg shadow-brand-green/25 hover:shadow-brand-green/40 transition-all disabled:opacity-70">
                  {submitting ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                      جارٍ الإرسال...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <Send className="w-4 h-4" />
                      إرسال الطلب
                    </span>
                  )}
                </Button>
              </form>
            </Reveal>

            {/* Map + Socials */}
            <Reveal delay={0.15}>
              <div className="space-y-5">
                <div className="glass-strong rounded-3xl p-2 overflow-hidden">
                  <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-slate-100">
                    <iframe
                      src="https://www.openstreetmap.org/export/embed.html?bbox=44.206%2C15.369%2C44.231%2C15.379&layer=mapnik&marker=15.374%2C44.218"
                      className="w-full h-full border-0"
                      loading="lazy"
                      title="موقع عصر الشمس"
                    />
                  </div>
                  <div className="p-4 flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-brand-green-dark flex-shrink-0" />
                    <div>
                      <div className="text-xs text-slate-500 font-mono uppercase tracking-wide">العنوان</div>
                      <div className="text-sm text-slate-700">{COMPANY.address}</div>
                    </div>
                  </div>
                </div>

                <div className="glass-strong rounded-3xl p-6">
                  <div className="text-xs text-slate-500 font-mono uppercase tracking-wide mb-4">تابعنا على</div>
                  <div className="grid grid-cols-3 gap-3">
                    <a href={COMPANY.socials.whatsapp} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-2 p-4 rounded-xl glass text-slate-600 hover:bg-green-500 hover:text-white transition-all">
                      <MessageCircle className="w-6 h-6" />
                      <span className="text-xs font-medium">واتساب</span>
                    </a>
                    <a href={COMPANY.socials.facebook} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-2 p-4 rounded-xl glass text-slate-600 hover:bg-blue-600 hover:text-white transition-all">
                      <Facebook className="w-6 h-6" />
                      <span className="text-xs font-medium">فيسبوك</span>
                    </a>
                    <a href={COMPANY.socials.linkedin} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-2 p-4 rounded-xl glass text-slate-600 hover:bg-sky-700 hover:text-white transition-all">
                      <Linkedin className="w-6 h-6" />
                      <span className="text-xs font-medium">لينكد إن</span>
                    </a>
                  </div>
                </div>

                <div className="glass-strong rounded-3xl p-6 text-center">
                  <Sparkles className="w-8 h-8 text-brand-green-dark mx-auto mb-3" />
                  <h4 className="font-heading font-bold text-lg mb-2">تفضّل المكالمة المباشرة؟</h4>
                  <p className="text-sm text-slate-600 mb-4">فريقنا متاح من السبت إلى الخميس</p>
                  <a href={`tel:${COMPANY.phones[0]}`} className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand-green to-brand-blue px-5 py-2.5 text-sm font-semibold text-white shadow-md hover:scale-105 transition-transform">
                    <Phone className="w-4 h-4" />
                    <span className="ltr-nums">{COMPANY.phones[0]}</span>
                  </a>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>
    </PageLayout>
  );
}
