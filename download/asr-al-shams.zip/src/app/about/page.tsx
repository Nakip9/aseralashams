"use client";

import Link from "next/link";
import { ArrowLeft, CheckCircle2, Building2, Globe2, ShieldCheck, Target, Eye, Heart, Award, Users, Handshake, Headphones } from "lucide-react";
import { PageLayout } from "@/components/site/PageLayout";
import { PageHero } from "@/components/site/PageHero";
import { Reveal, StaggerContainer, StaggerItem } from "@/components/site/Reveal";
import { CountUp } from "@/components/site/CountUp";
import { COMPANY, STATS, WHY_US, BRANDS } from "@/components/site/data";

const VALUES = [
  { icon: Target, title: "رسالتنا", desc: "توفير حلول طاقة شمسية موثوقة ومستدامة تساهم في بناء مستقبل طاقي أفضل لليمن والمنطقة." },
  { icon: Eye, title: "رؤيتنا", desc: "أن نكون الشركة الرائدة في مجال الطاقة المتجددة في اليمن، والشريك الأول لكل من يبحث عن طاقة نظيفة." },
  { icon: Heart, title: "قيمنا", desc: "الجودة، الشفافية، الالتزام، الابتكار، والمسؤولية البيئية — نلتزم بها في كل مشروع." },
];

const MILESTONES = [
  { year: "2020", ar: "تأسيس الشركة" },
  { year: "2021", ar: "الشراكة مع AE Solar" },
  { year: "2022", ar: "أول مشروع كبير 100+ kW" },
  { year: "2023", ar: "توسع الوكالات إلى 4 علامات" },
  { year: "2024", ar: "أكبر مشروع 409 kW" },
];

const WHY_ICONS: Record<string, any> = { Award, Users, Handshake, Headphones };

export default function AboutPage() {
  return (
    <PageLayout>
      <PageHero
        image="/hero/hero-bg-1.jpg"
        eyebrow="من نحن"
        title="من نحن"
        subtitle="نفخر بكوننا شريكاً موثوقاً في استيراد وتوريد وتركيب وتشغيل وصيانة أنظمة الطاقة الشمسية بجميع مكوناتها."
        breadcrumb="من نحن"
      />

      {/* Company story */}
      <section className="py-16 sm:py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-dots opacity-30 pointer-events-none" />
        <div className="container mx-auto px-4 relative">
          <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-start">
            <Reveal>
              <span className="inline-block text-xs sm:text-sm text-brand-green-dark tracking-widest font-mono uppercase mb-3">قصتنا</span>
              <h2 className="font-heading font-extrabold text-3xl sm:text-4xl mb-6">{COMPANY.fullName}</h2>
              <div className="space-y-4 text-slate-700 leading-loose text-sm sm:text-base">
                <p>{COMPANY.about.short}</p>
                <p className="text-slate-600">{COMPANY.about.long}</p>
              </div>
              <div className="flex flex-wrap gap-2 mt-7">
                {["N-Type / HJT / ABC", "On-Grid / Off-Grid / Hybrid", "Lithium-Ion", "TOP CABLE"].map((tag) => (
                  <span key={tag} className="inline-flex items-center gap-1.5 rounded-full bg-brand-green/10 border border-brand-green/30 px-3 py-1 text-xs text-brand-green-dark font-mono">
                    <CheckCircle2 className="w-3 h-3" />{tag}
                  </span>
                ))}
              </div>
            </Reveal>
            <Reveal delay={0.15}>
              <div className="grid grid-cols-2 gap-4">
                {STATS.map((s, i) => (
                  <div key={i} className="bento-card p-6 text-center group">
                    <div className="font-heading font-extrabold text-4xl sm:text-5xl text-gradient-solar mb-2">
                      <CountUp end={s.value} suffix={s.suffix} duration={2.2} />
                    </div>
                    <div className="text-xs sm:text-sm text-slate-500">{s.label}</div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Mission / Vision / Values */}
      <section className="py-16 sm:py-24 relative overflow-hidden bg-slate-50/50">
        <div className="container mx-auto px-4 relative">
          <Reveal className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl">رسالتنا ورؤيتنا وقيمنا</h2>
          </Reveal>
          <StaggerContainer className="grid md:grid-cols-3 gap-5 sm:gap-6" stagger={0.1}>
            {VALUES.map((v, i) => {
              const Icon = v.icon;
              return (
                <StaggerItem key={i}>
                  <div className="bento-card p-7 h-full">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-brand-green to-brand-blue flex items-center justify-center shadow-lg mb-5">
                      <Icon className="w-7 h-7 text-white" strokeWidth={2} />
                    </div>
                    <h3 className="font-heading font-bold text-xl mb-3 text-brand-green-dark">{v.title}</h3>
                    <p className="text-slate-600 text-sm leading-relaxed">{v.desc}</p>
                  </div>
                </StaggerItem>
              );
            })}
          </StaggerContainer>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16 sm:py-24 relative overflow-hidden">
        <div className="container mx-auto px-4 relative">
          <Reveal className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl">منذ البداية حتى اليوم</h2>
          </Reveal>
          <div className="max-w-3xl mx-auto">
            {MILESTONES.map((m, i) => (
              <Reveal key={i} delay={i * 0.05}>
                <div className="flex gap-5 group">
                  <div className="flex flex-col items-center flex-shrink-0">
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-brand-green to-brand-blue flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <span className="text-xs font-bold text-white ltr-nums">{m.year}</span>
                    </div>
                    {i < MILESTONES.length - 1 && <div className="w-0.5 flex-1 bg-gradient-to-b from-brand-green/40 to-transparent my-2 min-h-[2rem]" />}
                  </div>
                  <div className="pb-8 pt-3">
                    <p className="font-heading font-semibold text-base sm:text-lg text-slate-800">{m.ar}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Why us */}
      <section className="py-16 sm:py-24 relative overflow-hidden bg-slate-50/50">
        <div className="container mx-auto px-4 relative">
          <Reveal className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl">لماذا تختار عصر الشمس؟</h2>
          </Reveal>
          <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6" stagger={0.1}>
            {WHY_US.map((item, i) => {
              const Icon = WHY_ICONS[item.icon] ?? Award;
              return (
                <StaggerItem key={i}>
                  <div className="group bento-card p-7 h-full text-center">
                    <div className="relative inline-flex mb-5">
                      <div className="absolute inset-0 rounded-2xl bg-brand-green/30 blur-xl group-hover:bg-brand-green/50 transition-colors" />
                      <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-brand-green to-brand-blue flex items-center justify-center group-hover:rotate-6 transition-transform duration-500">
                        <Icon className="w-8 h-8 text-white" strokeWidth={2.2} />
                      </div>
                    </div>
                    <h3 className="font-heading font-bold text-lg sm:text-xl mb-3 group-hover:text-brand-green-dark transition-colors">{item.title}</h3>
                    <p className="text-slate-600 text-sm leading-relaxed">{item.description}</p>
                  </div>
                </StaggerItem>
              );
            })}
          </StaggerContainer>
        </div>
      </section>

      {/* Agencies */}
      <section className="py-16 sm:py-24 relative overflow-hidden">
        <div className="container mx-auto px-4 relative">
          <Reveal className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl">شركاؤنا العالميون</h2>
          </Reveal>
          <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6" stagger={0.1}>
            {BRANDS.map((brand, i) => (
              <StaggerItem key={i}>
                <div className="bento-card p-7 h-full">
                  <div className="flex items-center justify-center h-20 mb-5">
                    <img src={brand.logo} alt={brand.name} className="max-h-full max-w-full object-contain" />
                  </div>
                  <h3 className="font-heading font-bold text-lg text-center mb-2">{brand.name}</h3>
                  <p className="text-xs text-brand-green-dark text-center font-mono mb-3">{brand.role}</p>
                  <p className="text-slate-600 text-sm leading-relaxed text-center">{brand.description}</p>
                </div>
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 sm:py-24 relative overflow-hidden">
        <div className="container mx-auto px-4 relative">
          <Reveal>
            <div className="relative glass-strong rounded-3xl p-8 sm:p-12 overflow-hidden text-center">
              <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-brand-green/20 blur-3xl animate-pulse-glow" />
              <div className="absolute -bottom-20 -left-20 w-72 h-72 rounded-full bg-brand-blue/20 blur-3xl animate-pulse-glow" />
              <div className="relative">
                <h2 className="font-heading font-extrabold text-2xl sm:text-3xl mb-3">تعاون معنا</h2>
                <p className="text-slate-600 max-w-xl mx-auto mb-6">اكتشف كيف يمكننا مساعدتك في تحقيق أهدافك الطاقية.</p>
                <Link href="/contact" className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand-green to-brand-blue px-7 py-3.5 text-sm font-bold text-white shadow-lg hover:scale-105 transition-all">
                  اطلب عرض سعر الآن
                  <ArrowLeft className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </PageLayout>
  );
}
